package com.soss.checkout;

import org.junit.jupiter.api.*;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class CartServiceTest {
    Cart cart;
    CartService service;
    Map<Long, CheckoutProducts.ProductSnapshot> catalog;
    CheckoutOrders.Request submitted;
    CheckoutOrders.Receipt previous;
    boolean failOrder;

    @BeforeEach void setup() {
        cart = new Cart("customer"); cart.quantities.put(1L, 2); cart.quantities.put(2L, 1); cart.quantities.put(3L, 1); cart.promo = "BULA10";
        catalog = new HashMap<>();
        catalog.put(1L, new CheckoutProducts.ProductSnapshot(1L, "Milk", "milk", new BigDecimal("4.50"), true));
        catalog.put(2L, new CheckoutProducts.ProductSnapshot(2L, "Bread", "bread", new BigDecimal("3.20"), true));
        catalog.put(3L, new CheckoutProducts.ProductSnapshot(3L, "Chicken", "chicken", new BigDecimal("12.99"), true));
        CartRepository repository = (CartRepository) Proxy.newProxyInstance(getClass().getClassLoader(),
            new Class<?>[]{CartRepository.class}, (proxy, method, args) -> {
                if (method.getName().equals("lockByOwner") || method.getName().equals("findByOwner"))
                    return Optional.of(cart);
                throw new UnsupportedOperationException(method.getName());
            });
        CheckoutOrders orders = new CheckoutOrders() {
            public Optional<Receipt> findExisting(String owner, String token) { return Optional.ofNullable(previous); }
            public Receipt place(Request request) {
                if (failOrder) throw new IllegalStateException("Shared order service failed.");
                submitted = request; return new Receipt(7L);
            }
        };
        service = new CartService(repository, id -> Optional.ofNullable(catalog.get(id)), orders);
    }

    CheckoutForm form() {
        CheckoutForm f = new CheckoutForm(); f.setAddress("Vuci Road, Nausori");
        f.setDeliverySlot(service.slots().getFirst()); f.setPaymentMethod("M-PAiSA");
        f.setToken(cart.checkoutToken); return f;
    }

    @Test void totalsMatchScreenshot() {
        var basket = service.view("customer");
        assertEquals(new BigDecimal("25.19"), basket.subtotal());
        assertEquals(new BigDecimal("2.52"), basket.discount());
        assertEquals(new BigDecimal("25.67"), basket.total());
    }

    @Test void quantityAndPromoValidation() {
        service.change("customer", 1L, -1); assertEquals(1, cart.quantities.get(1L));
        service.change("customer", 1L, -1); assertFalse(cart.quantities.containsKey(1L));
        assertThrows(IllegalArgumentException.class, () -> service.change("customer", 1L, 99));
        assertThrows(IllegalArgumentException.class, () -> service.promo("customer", "FREE"));
    }

    @Test void sharedOrderReceivesServerCalculatedSnapshot() {
        assertEquals(7L, service.place("customer", form()).orderId());
        assertEquals(new BigDecimal("25.67"), submitted.total());
        assertEquals("customer", submitted.owner());
        assertEquals(3, submitted.items().size());
        assertTrue(cart.quantities.isEmpty());
    }

    @Test void failureDoesNotClearCart() {
        failOrder = true;
        assertThrows(IllegalStateException.class, () -> service.place("customer", form()));
        assertEquals(3, cart.quantities.size());
    }

    @Test void repeatedCheckoutUsesSharedReceipt() {
        previous = new CheckoutOrders.Receipt(9L);
        assertEquals(9L, service.place("customer", form()).orderId());
        assertNull(submitted);
    }

    @Test void staleTokenAndInvalidDeliveryAreRejected() {
        var f = form(); service.change("customer", 1L, 1);
        assertThrows(IllegalArgumentException.class, () -> service.place("customer", f));
        var invalid = form(); invalid.setDeliverySlot("yesterday");
        assertThrows(IllegalArgumentException.class, () -> service.place("customer", invalid));
    }

    @Test void missingProductCanBeRemoved() {
        catalog.remove(2L); service.change("customer", 2L, -1);
        assertEquals(2, service.view("customer").count());
    }

    @Test void emptyCartCannotBeOrdered() {
        cart.quantities.clear();
        assertThrows(IllegalArgumentException.class, () -> service.place("customer", form()));
    }
}
