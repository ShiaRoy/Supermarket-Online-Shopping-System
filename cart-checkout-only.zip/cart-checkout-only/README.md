# Cart / Checkout module only

Use this bundle instead of the earlier standalone demo ZIPs.

## Scope

Includes only Cart, CartRepository, CartService, CheckoutForm, CartController,
CartApiController, CartApiErrors, and two cart-owned integration contracts:
CheckoutProducts and CheckoutOrders. Their records are handoff DTOs, not shared domain entities.

Removed from this handoff: Product, ProductRepository, OrderItem, ShopOrder, OrderRepository,
PaymentService, PaymentApiController, SecurityConfig, PaymentProvider, demo seed data, application
entry point, database configuration, catalog/search routes, order-history/confirmation pages,
payment APIs and authentication routes.

The existing shared Products, Orders/Payments and Authentication modules own those responsibilities.

## Integration required

This is a Spring Boot module source handoff, not a standalone runnable application.
The optional pom.xml builds a plain module JAR. Do not replace the shared application's pom.xml.
Use the shared project's Java/package/dependency versions when integrating.

1. Move these classes under the shared application's component/entity/repository scan.
2. Provide a Spring bean implementing CheckoutProducts using the shared Products service.
   Map the existing product ID, name, icon/image placeholder, price and availability to ProductSnapshot.
   Product IDs are assumed to be Long; align the contract with the shared model if necessary.
3. Provide a Spring bean implementing CheckoutOrders using the shared Orders service.
   findExisting must scope lookups by authenticated owner + checkout token.
   place must persist the shared order and items, enforce a unique owner/token pair,
   and return its order ID. Do not add replacement order entities here.
4. Orders.place must join CartService's transaction with the same datasource/transaction manager.
   No REQUIRES_NEW or remote HTTP order placement: otherwise order creation and cart clearing
   would not be atomic. A remote Orders module needs an outbox/saga integration first.
5. Keep the shared Authentication security chain. Require authenticated customers for /cart,
   /checkout, /api/cart/** and /api/checkout, and leave CSRF protection enabled.
   The controllers use Principal.getName(); map this to your shared stable account identity.
6. Provision a cart for each account through CartService.provision during account setup or migration.
7. Keep the shared datasource and schema migration conventions. Cart persists shop_cart and
   shop_cart_line only. Review those mappings against any existing cart schema before integrating.
8. Match the shared confirmation URL: CartController currently redirects to /confirmation/{orderId}.
   Home (/), Search (/search), Confirmation (/confirmation), My orders (/orders), and logout (/logout)
   are links only; this module does not implement them.
9. Use templates/cart/cart.html and templates/cart/fragments.html, or merge the cart view into
   the shared layout. CSS is namespaced by filename at /css/cart-checkout.css.
10. Reconcile the three payment labels with the shared payment enum. There is no payment API,
    payment state, card processing, or security configuration in this module.
11. Review the sample delivery fee (FJD 3), BULA10 discount and future Fiji delivery slots.

## Cart-owned endpoints

| Method | Path | Responsibility |
| --- | --- | --- |
| GET | /cart | Cart + checkout HTML |
| POST | /cart/quantity | Increase/decrease quantity |
| POST | /cart/promo | Apply/remove promo |
| POST | /checkout | Delegate order creation and redirect |
| GET | /api/cart | Cart details and server totals |
| POST | /api/cart/quantity | JSON productId and delta (+1/-1) |
| POST | /api/cart/promo | JSON code |
| GET | /api/cart/delivery-slots | Available slots |
| POST | /api/checkout | CheckoutForm JSON; returns orderId |

Get API CSRF credentials from the shared Authentication module or the shared page.
No duplicate /api/csrf, product, order, or payment routes are included.

## Verification

CartServiceTest contains focused unit tests using in-memory integration doubles.
These do not verify the shared adapters, authentication, real database locking or transaction rollback.
Run those integration checks after the shared modules are connected.

The linked GitHub branch could not be read from this environment, so shared class names and
package mappings have not been guessed. No Git commit or push was made.

Build attempt: Maven verify was blocked by access restrictions on a cached Jackson dependency. The module build and included unit tests are not verified in this session.
